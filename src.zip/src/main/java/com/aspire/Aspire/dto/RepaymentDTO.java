package com.aspire.Aspire.dto;

import java.math.BigDecimal;

public class RepaymentDTO {
    private BigDecimal repaymentAmount;

    public BigDecimal getRepaymentAmount() {
        return repaymentAmount;
    }

    public void setRepaymentAmount(BigDecimal repaymentAmount) {
        this.repaymentAmount = repaymentAmount;
    }
}
