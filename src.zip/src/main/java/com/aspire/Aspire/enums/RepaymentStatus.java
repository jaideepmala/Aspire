package com.aspire.Aspire.enums;

public enum RepaymentStatus {
    PENDING,
    PAID
}