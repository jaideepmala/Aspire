package com.aspire.Aspire.enums;

public enum LoanApplicationStatus {
    PENDING,
    APPROVED,
    REJECTED,
    PAID
}