package com.aspire.Aspire.repository;

import com.aspire.Aspire.model.Repayment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepaymentRepository extends JpaRepository<Repayment, Long> {
}
