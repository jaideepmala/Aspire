package com.aspire.Aspire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AspireApplication {

	public static void main(String[] args) {
		SpringApplication.run(AspireApplication.class, args);
	}

}
